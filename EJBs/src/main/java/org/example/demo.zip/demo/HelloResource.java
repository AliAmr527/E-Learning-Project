package org.example.demo;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/hello")
public class HelloResource {
    @GET
    @Produces("text/plain")
    public String hello() {
        return "Hello, World!";
    }

    @GET
    @Path("/pojo")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPojoResponse() {
        Person person = new Person("Abhinayak", 12);
        return Response
                .status(Response.Status.OK)
                .entity(person)
                .build();
    }

    @GET
    @Path("/ok")
    public Response getOkResponse() {
        String message = "This is a text a7a3";
        return Response
                .status(Response.Status.OK)
                .entity(message)
                .build();
    }


    @POST
    @Path("/addNigga")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addNigga(Person person) {
        Person person2 = new Person();
        person2.setName(person.getName());
        person2.setAge(person.getAge());
        System.out.println(person2.getName());
        System.out.println(person2.getAge());
        return Response
                .status(Response.Status.OK)
                .entity(person2)
                .build();
    }

    @POST
    @Path("/{name}")
    public Response addNigga(@PathParam("name") String name) {
        String message = "{\"hello\": \"This is a J " + name + " SON response\"}";

        return Response
                .status(Response.Status.OK)
                .entity(message)
                .type(MediaType.APPLICATION_JSON)
                .build();
    }
}